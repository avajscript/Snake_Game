import pygame as pg
import copy
from DoublyLinkedList import DoublyLinkedList
from DoublyLinkedList import Node

pg.init()

# screen dimensions
BOARD_WIDTH = 400
COLUMNS = 10
BLOCK_WIDTH = BOARD_WIDTH / COLUMNS

# colors
DARK_PURPLE = (48, 0, 80)
PURPLE = (83, 2, 137)
COLORS_TUPLE = (DARK_PURPLE, PURPLE)
SNAKE_COLOR = (148, 255, 122)

class TestNode:
    def __init__(self, num):
        self.num = num

    def print_msg(self):
        print(f"Num: {self.num}")



class Segment(Node):
    def __init__(self, x, y):
        super().__init__()
        self.x = x
        self.y = y

    def set_point(self, point):
        self.x, self.y = point


class Snake:
    def __init__(self, color, block_width):
        self.list = DoublyLinkedList()
        self.color = color
        self.initialize_snake()
        self.block_width = block_width
        self.dir = "right"

    def initialize_snake(self):
        self.list.insert_end(Segment(5, 5))
        self.list.insert_end(Segment(4, 5))
        self.list.insert_end(Segment(3, 5))

    def move_snake(self):
        # update the head position
        head_copy = copy.copy(self.list.head)
        if self.dir == "right":
            if head_copy.x < COLUMNS:
                head_copy.x += 1
        elif self.dir == "left":
            if head_copy.x > 0:
                head_copy.x -= 1
        elif self.dir == "up":
            if head_copy.y > 0:
                head_copy.y -= 1
        elif self.dir == "down":
            if head_copy.y < COLUMNS:
                head_copy.y += 1

        current = self.list.head
        prev_values = (current.x, current.y)
        current.x = head_copy.x
        current.y = head_copy.y
        current = current.next

        while current:
            temp_values = (current.x, current.y)
            current.set_point(prev_values)
            prev_values = temp_values
            current = current.next

    def draw(self, surface):
        segment = self.list.head
        while segment:
            pg.draw.rect(surface, self.color, (segment.x * self.block_width, segment.y * self.block_width,
                                               self.block_width, self.block_width))
            segment = segment.next

class Board:
    def __init__(self, width, columns, block_width):
        self.surface = pg.Surface((width, width))
        self.width = width
        self.columns = columns
        self.block_width = block_width

    def draw(self, surface):
        for y in range(COLUMNS):
            for x in range(COLUMNS):
                pg.draw.rect(self.surface, COLORS_TUPLE[(x + y) % 2 == 0],
                             (x * self.block_width, y * self.block_width, self.block_width, self.block_width))
        surface.blit(self.surface, (0, 0))


# game state
running = True

# game objects
screen = pg.display.set_mode((BOARD_WIDTH, BOARD_WIDTH))
board = Board(BOARD_WIDTH, COLUMNS, BLOCK_WIDTH)
snake = Snake(SNAKE_COLOR, BLOCK_WIDTH)





board.draw(screen)
snake.draw(screen)
pg.display.update()


while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            pg.quit()
            exit()
        elif event.type == pg.KEYDOWN:
            if event.key == pg.K_w:
                snake.dir = "up"
                snake.move_snake()
            elif event.key == pg.K_d:
                snake.dir = "right"
                snake.move_snake()
            elif event.key == pg.K_s:
                snake.dir = "down"
                snake.move_snake()
            elif event.key == pg.K_a:
                snake.dir = "left"
                snake.move_snake()

            board.draw(screen)
            snake.draw(screen)
            pg.display.update()


